package uploader.gui;

public interface StudentTableListener {
	
	public void rowDeleted(int row);

}
