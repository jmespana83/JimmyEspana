package uploader.gui;

import java.util.List;

import javax.swing.table.AbstractTableModel;

import uploader.model.Student;

public class StudentTableModel extends AbstractTableModel {
	
	private List<Student> db;
	
	private String[] colNames = {"ID", "Name", "Student ID", "Age", "Grade", "Gender"};
	
	public StudentTableModel() {
	}
	
	@Override
	public String getColumnName(int column) {
		// TODO Auto-generated method stub
		return colNames[column];
	}

	public void setData(List<Student> db) {
		this.db = db;
	}

	@Override
	public int getColumnCount() {
		return 6;
	}

	@Override
	public int getRowCount() {
		return db.size();
	}

	@Override
	public Object getValueAt(int row, int col) {
		Student student = db.get(row);
		
		if(col == 0) {
			return student.getId();
		}
		else if(col == 1) {
			return student.getName();
		}
		else if (col == 2) {
			return student.getStudentId();
		}
		else if (col == 3) {
			return student.getAge();
		}
		else if (col == 4) {
			return student.getGrade();
		}
		else if(col == 5) {
			return student.getGender();
		}
		
	
		
		return null;
		

	}
	
}
