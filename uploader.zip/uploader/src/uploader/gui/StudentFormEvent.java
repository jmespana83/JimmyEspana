package uploader.gui;

import java.util.EventObject;

public class StudentFormEvent extends EventObject {
	
	private String name;
	private String studentId;
	private String age;
	private String grade;
	private String gender;
	
	public StudentFormEvent(Object source) {
		super(source);
	}

	public StudentFormEvent(Object source, String name, String studentId, String age, String grade, String gender) {
		super(source);
		
		this.name = name;
		this.studentId = studentId;
		this.age = age;
		this.grade = grade;
		this.gender = gender;
		
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getStudentId() {
		return studentId;
	}

	public void setStudentId(String studentId) {
		this.studentId = studentId;
	}

	public String getAge() {
		return age;
	}

	public void setAge(String age) {
		this.age = age;
	}

	public String getGrade() {
		return grade;
	}

	public void setGrade(String grade) {
		this.grade = grade;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}
	
	
	

}
