package uploader.gui;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.List;

import javax.swing.BorderFactory;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.border.Border;

import uploader.model.Student;

public class TablePanel extends JPanel {
	
	private JTable table;
	private StudentTableModel tableModel;
	private JPopupMenu popup;
	
	private StudentTableListener studentTableListener;
	
	public TablePanel() {
		
		tableModel = new StudentTableModel();
		
		table = new JTable(tableModel);
		
		popup = new JPopupMenu();
		
		JMenuItem removeItem = new JMenuItem("Delete Row");
		popup.add(removeItem);
		
		table.addMouseListener(new MouseAdapter() {

			@Override
			public void mousePressed(MouseEvent e) {
				
				int row = table.rowAtPoint(e.getPoint());
				
				table.getSelectionModel().setSelectionInterval(row, row);
				
				if (e.getButton()  == MouseEvent.BUTTON3)  {
					popup.show(table, e.getX(), e.getY());
				}
			}
		});
		
		removeItem.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				int row  = table.getSelectedRow();
				
				if(studentTableListener != null) {
					studentTableListener.rowDeleted(row);
					tableModel.fireTableRowsDeleted(row, row);
				}
			}
		});
		
		
		setLayout(new BorderLayout());
		
		add(new JScrollPane(table), BorderLayout.CENTER);
		
		Border border = BorderFactory.createEmptyBorder(5, 5, 5, 5);
		
		setBorder(border);
	}
	
	
	public void setData(List<Student> db) {
		tableModel.setData(db);
	}
	
	public void refresh() {
		tableModel.fireTableDataChanged();
	}
	
	public void setStudentTableListener(StudentTableListener listener) {
		this.studentTableListener = listener;
	}

}
