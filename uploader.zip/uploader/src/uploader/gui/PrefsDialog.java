package uploader.gui;

import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JSpinner;
import javax.swing.SpinnerNumberModel;

public class PrefsDialog extends JDialog {
	
	private JButton okButton;
	private JButton cancelButton;
	private JSpinner portSpinner;
	private SpinnerNumberModel spinnerModel;
	
	public PrefsDialog(JFrame parent) {
		super(parent, "Preferences", false);
		
		setSize(400,300);
		setLocationRelativeTo(parent);
		
		okButton = new JButton("OK");
		cancelButton = new JButton("CANCEL");
		
		okButton.addActionListener(new ActionListener() {
		
			@Override
			public void actionPerformed(ActionEvent e) {
				Integer value  = (Integer)portSpinner.getValue();
				
				System.out.print(value);
				
				setVisible(false);
			}
		});
		
		cancelButton.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
			}
		});
		
		
		spinnerModel = new SpinnerNumberModel(3306, 0, 9999, 1); 
		portSpinner = new JSpinner(spinnerModel);
		
		setLayout(new GridBagLayout());
		
		GridBagConstraints gc = new GridBagConstraints();
		
		
		gc.fill = GridBagConstraints.NONE;
		gc.weightx = 1;
		gc.weighty = 1;
		
//		first row
		gc.gridy = 0;
		gc.gridx = 0;
		
		gc.gridy++;		
		add(new JLabel("Port: "), gc);
		
		gc.gridx++;
		add(portSpinner, gc);
		
//		second row
		gc.gridy++;
		gc.gridx = 0;
		
		add(okButton, gc);
		
		gc.gridx++;
		add(cancelButton, gc);
		
		
		
	}
}
