package uploader.gui;

import java.util.EventListener;

public interface FormListener extends EventListener {
	
	public void studentFormEventOccurred(StudentFormEvent e);

}
