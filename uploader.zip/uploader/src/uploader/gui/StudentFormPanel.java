package uploader.gui;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.ButtonGroup;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextField;
import javax.swing.border.Border;

public class StudentFormPanel extends JPanel {
	
	private FormListener formListener;
	
	private JLabel nameLabel;
	private JLabel idLabel;
	private JLabel gradeLabel;
	private JLabel ageLabel;
	private JLabel genderLabel;
	
	private JTextField nameField;
	private JTextField idField;
	private JTextField ageField;
	
	private JComboBox<GradeCategory> gradeCombo;
	
	private JRadioButton maleRadio;
	private JRadioButton femaleRadio;
	
	private ButtonGroup genderGroup;
	
	private JButton submitButton;
	
	private Color backgroundColor;
	
	public StudentFormPanel() {
		Dimension dim = getPreferredSize();
		dim.width = 250;
		
		setPreferredSize(dim);
		
		// widget initilization
		nameLabel = new JLabel("Full Name:");
		idLabel = new JLabel("Student ID:");
		ageLabel = new JLabel("Age:");
		gradeLabel = new JLabel("Grade:");
		genderLabel = new JLabel("Gender:");
		
		nameField = new JTextField(10);
		idField = new JTextField(10);
		ageField = new JTextField(10);
		
		gradeCombo = new JComboBox();
		
		maleRadio = new JRadioButton();
		femaleRadio = new JRadioButton();
		
		genderGroup = new ButtonGroup();
		
		
		submitButton = new JButton("SUBMIT");
		
		
		// combo box model and elements using gradecat class
		DefaultComboBoxModel<GradeCategory> gradeModel = new DefaultComboBoxModel<GradeCategory>();
		gradeModel.addElement(new GradeCategory(0, "Freshman"));
		gradeModel.addElement(new GradeCategory(1, "Sophomore"));
		gradeModel.addElement(new GradeCategory(2, "Junior"));
		gradeModel.addElement(new GradeCategory(3, "Senior"));
		
		gradeCombo.setModel(gradeModel);
		gradeCombo.setSelectedIndex(0);
		
		// genderbutton groups
		genderGroup.add(maleRadio);
		genderGroup.add(femaleRadio);
		
		maleRadio.setSelected(true);
		
		maleRadio.setActionCommand("male");
		femaleRadio.setActionCommand("female");
		
		
		// submit button action listener
		submitButton.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				String name = nameField.getText();
				String id = idField.getText();
				String age = ageField.getText();
				String gender = genderGroup.getSelection().getActionCommand();
				
				GradeCategory grade = (GradeCategory) gradeCombo.getSelectedItem();
				
				StudentFormEvent event = new StudentFormEvent(e, name, id, age, grade.getGrade(), gender );
				
				if (formListener != null) {
					formListener.studentFormEventOccurred(event);
				}
				
			}
			
		});

		
		
		
		
		
		layoutComponents();
		styling();
	}
	
	// sets form listener 
	public void setFormListener(FormListener listener) {
		this.formListener = listener;
	}
	
	
	// createlayout method
	public void layoutComponents() {
		
		// form panel border
		Border innerBorder = BorderFactory.createTitledBorder("Add Student");
		Border outerBorder = BorderFactory.createEmptyBorder(0, 5, 5, 5);
		
		setBorder(BorderFactory.createCompoundBorder(outerBorder, innerBorder));
		
		
		// form panel grid layout
		
		setLayout(new GridBagLayout());
		
		GridBagConstraints gc = new GridBagConstraints();
		
	
//		first row ------------------------------------------------
		gc.gridy = 0;
		
		gc.weightx = 1;
		gc.weighty = .1;
		
		
		// name label
		gc.anchor = GridBagConstraints.LINE_END;
		gc.insets = new Insets(0,0,0,5);
		
		gc.gridx = 0;
		
		add(nameLabel, gc);

		// name field
		gc.anchor = GridBagConstraints.LINE_START;
		gc.insets = new Insets(0,0,0,0);
		
		gc.gridx = 1;
		
		add(nameField, gc);

//		second row ------------------------------------------------
		gc.gridy++;

		gc.weightx = 0;
		gc.weighty = .1;
		
		// id label
		gc.anchor = GridBagConstraints.LINE_END;
		gc.insets = new Insets(0,0,0,5);
		
		gc.gridx = 0;
		
		add(idLabel, gc);

		// id field
		gc.anchor = GridBagConstraints.LINE_START;
		gc.insets = new Insets(0,0,0,0);
		
		gc.gridx = 1;
		
		add(idField, gc);

//		third row ------------------------------------------------
		gc.gridy++;

		gc.weightx = 0;
		gc.weighty = .1;
		
		// age label
		gc.anchor = GridBagConstraints.LINE_END;
		gc.insets = new Insets(0,0,0,5);
		
		gc.gridx = 0;
		
		add(ageLabel, gc);

		// age field
		gc.anchor = GridBagConstraints.LINE_START;
		gc.insets = new Insets(0,0,0,0);
		
		gc.gridx = 1;
		
		add(ageField, gc);

//		fourth row ------------------------------------------------
		gc.gridy++;
		
		gc.weightx = 0;
		gc.weighty = .1;
		
		// grade label
		gc.anchor = GridBagConstraints.LINE_END;
		gc.insets = new Insets(0,0,0,5);
		
		gc.gridx = 0;
		
		add(gradeLabel, gc);

		// grade combo box
		gc.anchor = GridBagConstraints.LINE_START;
		gc.insets = new Insets(0,0,0,0);
		
		gc.gridx = 1;
		
		add(gradeCombo, gc);

//		fifth row ------------------------------------------------
		gc.gridy++;
		
		gc.weightx = 0;
		gc.weighty = .1;
		
		// male label
		gc.anchor = GridBagConstraints.LINE_START;
		gc.insets = new Insets(0,0,0,0);
		
		gc.gridx = 1;
		
		add(new JLabel("Male"), gc);

		// male radio button
		gc.anchor = GridBagConstraints.LINE_END;
		gc.insets = new Insets(0,0,0,0);
		
		gc.gridx = 0;
		
		add(maleRadio, gc);
		
//		// gender label
//		gc.anchor = GridBagConstraints.PAGE_END;
//		gc.insets = new Insets(0,0,0,0);
//		gc.gridx = 0;
//		add(genderLabel, gc);
		
//		sixth row ------------------------------------------------
		gc.gridy++;
		
		gc.weightx = 0;
		gc.weighty = 0;
		
		// female label
		gc.anchor = GridBagConstraints.LINE_START;
		gc.insets = new Insets(0,0,0,0);
		
		gc.gridx = 1;
		
		add(new JLabel("Female"), gc);

		// male radio button
		gc.anchor = GridBagConstraints.LINE_END;
		gc.insets = new Insets(0,0,0,0);
		
		gc.gridx = 0;
		
		add(femaleRadio, gc);
		
		
//		button
		gc.gridy++;
		
		gc.weightx = 1;
		gc.weighty = 0.2;
		
		gc.anchor = GridBagConstraints.FIRST_LINE_START;
		gc.insets = new Insets(30,0,0,0);
		
		gc.gridx = 1;
		
		add(submitButton, gc);
		
	}
	
	
	public void styling() {
		backgroundColor = new Color(238,238,238);
		
		submitButton.setBackground(backgroundColor);
		submitButton.setForeground(Color.black);
		
		gradeCombo.setBackground(backgroundColor);
		gradeCombo.setForeground(Color.black);
	}
	
	
	
	
	
	
	
	

}






// grade cat class
class GradeCategory {
	private int id;
	private String grade;
	
	
	public GradeCategory(int id, String grade) {
		this.id = id;
		this.grade = grade;
	}


	public int getId() {
		return id;
	}


	public void setId(int id) {
		this.id = id;
	}


	public String getGrade() {
		return grade;
	}


	public void setGrade(String grade) {
		this.grade = grade;
	}
	
	public String toString() {
		return grade;
	}
	
	
}



















