package uploader.gui;

import java.util.EventListener;

public interface TabButtonListener extends EventListener{

	public void tabButtonEventOccurred(TabButtonEvent e);
	
}
