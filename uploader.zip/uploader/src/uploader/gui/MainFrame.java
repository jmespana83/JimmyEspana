package uploader.gui;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.io.IOException;

import javax.swing.JCheckBoxMenuItem;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.KeyStroke;

import uploader.controller.Controller;

public class MainFrame extends JFrame {
	
	private static final int WIDTH = 900, HEIGHT = 600;
	
//	private TextPanel textPanel;
	private TablePanel tablePanel;
	private StudentFormPanel studentFormPanel;
	
	private ToolBar toolBar;
	
	private JFileChooser fileChooser;
	
	private Controller controller;
	
	private PrefsDialog prefsDialog;
	
	public MainFrame() {
		 
		super("Uploader 0.8");
		
		setMinimumSize(new Dimension(600, 400));
		setMaximumSize(new Dimension(WIDTH, HEIGHT));
		setSize(WIDTH, HEIGHT);
		
		Toolkit tk = Toolkit.getDefaultToolkit();
		Dimension screenSize = tk.getScreenSize();
		int screenHeight = (int)screenSize.getHeight();
		int screenWidth = (int)screenSize.getWidth();
		
		setLocation(screenWidth/4, screenHeight/4);
		
		setResizable(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setVisible(true);
		
		controller = new Controller();
		
		fileChooser = new JFileChooser();
		fileChooser.addChoosableFileFilter(new StudentFileFilter());
		
//		textPanel = new TextPanel();
		tablePanel = new TablePanel();
		studentFormPanel = new StudentFormPanel();
		
		// sets data for table panel, passes in students list from controller get students method 
		tablePanel.setData(controller.getStudents());
		
		tablePanel.setStudentTableListener(new StudentTableListener() {
			public void rowDeleted(int row) {
				
				controller.removeStudent(row);
				
			}
		});
		
		toolBar = new ToolBar();
		
		prefsDialog = new PrefsDialog(null);
		
		setLayout(new BorderLayout());
		setJMenuBar(createMenuBar());
		
		
		//formPanel listener
		studentFormPanel.setFormListener(new FormListener() {

			@Override
			public void studentFormEventOccurred(StudentFormEvent e) {
				
				
				controller.addStudent(e);
				tablePanel.refresh();
				
				
//				textPanel.appendText("Name: " + e.getName() + "\n");
//				textPanel.appendText("Student ID: " + e.getStudentId() + "\n");
//				textPanel.appendText("Age: " + e.getAge() + "\n");
//				textPanel.appendText("Grade: " + e.getGrade() + "\n");
//				textPanel.appendText("Gender: " + e.getGender() + "\n");
				
			}
			
		});
		
		// toolbar listener 
		toolBar.setToolBarListener(new TabButtonListener() {

			@Override
			public void tabButtonEventOccurred(TabButtonEvent e) {
//				// 0 = textPanel id
//				if (e.getTabId() == 0) {
//					if (textPanel.isVisible()) {
//						textPanel.setVisible(e.getShowTextPanel());
//						
//					}
//					else textPanel.setVisible(!e.getShowTextPanel());
//				}
				
				// 1 = formpPanel id 
				if (e.getTabId() == 1) {
					if(studentFormPanel.isVisible()) studentFormPanel.setVisible(e.getShowFormPanel());
					else studentFormPanel.setVisible(!e.getShowFormPanel());
				}
				
				// 2 = tablepanel id
				else if (e.getTabId() == 2) {
					if(tablePanel.isVisible()) tablePanel.setVisible(e.getShowTablePanel());
					else tablePanel.setVisible(!e.getShowTablePanel());
					}
			}
			
		});
	
		
		add(tablePanel, BorderLayout.CENTER);
//		add(textPanel, BorderLayout.EAST);
		add(studentFormPanel, BorderLayout.WEST);
		add(toolBar, BorderLayout.NORTH);
		
		
	}
	
	
	
	// jmenu bar method
	private JMenuBar createMenuBar() {
		
		// main menu bar 
		JMenuBar menuBar = new JMenuBar();
		
		// sub bars 
		JMenu fileMenu = new JMenu("File");
		JMenu windowMenu = new JMenu("Window");
		JMenu toolMenu = new JMenu("Tools");
		
// 		file menu items ------------------------------------------
		JMenuItem exportDataItem = new JMenuItem("Export Data...");
		fileMenu.add(exportDataItem);
		
		JMenuItem importDataItem = new JMenuItem("Import Data...");
		fileMenu.add(importDataItem);
		
		// separator 
		fileMenu.addSeparator();
		
		JMenuItem exitItem = new JMenuItem("Exit");
		fileMenu.add(exitItem);
		
//		window menu items -----------------------------------------
		JMenuItem showMenu = new JMenu("Show View");
		windowMenu.add(showMenu);
		
		JCheckBoxMenuItem studentFormItem = new JCheckBoxMenuItem("Student Form");
		showMenu.add(studentFormItem);
		studentFormItem.setSelected(true);
		
		JCheckBoxMenuItem tableItem = new JCheckBoxMenuItem("Data Table");
		showMenu.add(tableItem);
		tableItem.setSelected(true);
		
//		tool menu items ------------------------------------------
		
		// prefs menu item 
		JMenuItem prefsItem = new JMenuItem("Preferences...");
		toolMenu.add(prefsItem);
		
//		JCheckBoxMenuItem textPanelFormItem = new JCheckBoxMenuItem("Text Panel");
//		showMenu.add(textPanelFormItem);
//		textPanelFormItem.setSelected(true);
		

		// add menus to menu bar
		menuBar.add(fileMenu);
		menuBar.add(windowMenu);
		menuBar.add(toolMenu);
	
		
		// file, window, showmenu, and exit mnemonics/accelerator 
		fileMenu.setMnemonic(KeyEvent.VK_F);
		exitItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_X, ActionEvent.CTRL_MASK));
		windowMenu.setMnemonic(KeyEvent.VK_W);
		studentFormItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_G, ActionEvent.CTRL_MASK));
		tableItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_T, ActionEvent.CTRL_MASK));
//		textPanelFormItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_T, ActionEvent.CTRL_MASK));
		
		// import and export accelerators
		importDataItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_I, ActionEvent.CTRL_MASK));
		exportDataItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_E, ActionEvent.CTRL_MASK));
		
		
		
		// action listener for windowmenu-showmenu-add student form menu item
		studentFormItem.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				boolean isTicked = studentFormItem.isSelected();
	
				studentFormPanel.setVisible(isTicked);
				toolBar.setFormTabButtonVisible(isTicked);
			}
		});
		
		// action listener for windowmneu-showmneu-data table menu item
		
		tableItem.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				boolean isTicked = tableItem.isSelected();
				
				tablePanel.setVisible(isTicked);
				toolBar.setTableTabButtonVisible(isTicked);
				
			}
			
		});
		
		// action listener for prefsdialog
		prefsItem.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				prefsDialog.setVisible(true);
			}
		});
		
		
		// action listener for windowmenu-showmenu-textpanel check box item
//		textPanelFormItem.addActionListener(new ActionListener() {
//			public void actionPerformed(ActionEvent e) {
//				boolean isTicked = textPanelFormItem.isSelected();
//				
//				textPanel.setVisible(isTicked);
//				toolBar.setTextTabButtonVisible(isTicked);
//			}
//		});
		
		
		// import file action listener for file chooser
		importDataItem.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				if (fileChooser.showOpenDialog(MainFrame.this) == JFileChooser.APPROVE_OPTION) {
					
					try {
						controller.loadFromFile(fileChooser.getSelectedFile());
						tablePanel.refresh();
					} catch (IOException e1) {
						
						JOptionPane.showMessageDialog(MainFrame.this, "Could not load data from file.", "Error", JOptionPane.ERROR_MESSAGE);
					}
					
					
					System.out.print(fileChooser.getSelectedFile());
				}
			}
		});
		
	// export data file action listener for file chooser
		exportDataItem.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				if(fileChooser.showSaveDialog(MainFrame.this) == JFileChooser.APPROVE_OPTION) {
					
					try {
						controller.saveToFile(fileChooser.getSelectedFile());
					} catch (IOException e1) {
						
						JOptionPane.showMessageDialog(MainFrame.this, "Coould not save data to file.", "Error", JOptionPane.ERROR_MESSAGE);
					}
					System.out.print(fileChooser.getSelectedFile());
				}
			}
			
		});
		
		exitItem.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				int action = JOptionPane.showConfirmDialog(MainFrame.this, "Are you sure you want to exit?", "Confirm Exit", JOptionPane.OK_CANCEL_OPTION);
				if(action == JOptionPane.OK_OPTION) {System.exit(0);}
				
			}
			
		});

		
		return menuBar;
		
	}

}




















