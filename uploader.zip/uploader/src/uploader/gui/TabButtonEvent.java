package uploader.gui;

import java.util.EventObject;

public class TabButtonEvent extends EventObject{
	
	private boolean showTextPanel;
	private boolean showFormPanel;
	private boolean showTablePanel;
	private int tabId;

	public TabButtonEvent(Object source, boolean showTextPanel, boolean showFormPanel, boolean showTablePanel, int tabId) {
		super(source);
		
		this.showTextPanel = showTextPanel;
		this.showFormPanel = showFormPanel;
		this.showTablePanel = showTablePanel;
		this.tabId = tabId;
	}
	
	public boolean getShowTextPanel() {
		return showTextPanel;
	}
	
	public boolean getShowFormPanel() {
		return showFormPanel;
	}
	
	public boolean getShowTablePanel() {
		return showTablePanel;
	}
	
	public int getTabId() {
		return tabId;
	}

}
