package uploader.gui;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.border.Border;

public class ToolBar extends JPanel {
	
	private FlowLayout fl;
	
//	private JButton textPanelTab;
	private JButton formPanelTab;
	private JButton tablePanelTab;
	
	private TabButtonListener tabButtonListener;
	
	private Color backgroundColor;
	
	private Border btnBorder;
	
	
	public ToolBar() {
		Dimension dim = getPreferredSize();
		dim.height = 40;
		setPreferredSize(dim);
	
		fl = new FlowLayout(FlowLayout.CENTER, 10, 6);
	
		
		btnBorder = BorderFactory.createCompoundBorder(BorderFactory.createEmptyBorder(1,1,1,1), BorderFactory.createEtchedBorder());
		
//		textPanelTab = new JButton("SHOW TEXT AREA");
		formPanelTab = new JButton("SHOW STUDENT FORM");
		tablePanelTab = new JButton("SHOW TABLE");
		
//		textPanelTab.setPreferredSize(new Dimension(140, 25));
//		textPanelTab.setBorder(btnBorder);
		
		formPanelTab.setPreferredSize(new Dimension(170, 25));
		formPanelTab.setBorder(btnBorder);
		
		tablePanelTab.setPreferredSize(new Dimension(170, 25));
		tablePanelTab.setBorder(btnBorder);
		
		
		setLayout(fl);
		
		Border border = BorderFactory.createEmptyBorder(5,5,0,5);
		setBorder(border);
		
		
		add(formPanelTab, fl);
//		add(textPanelTab, fl);
		add(tablePanelTab, fl);
		
		
		
//		textPanelTab.addActionListener(new ActionListener() {
//			public void actionPerformed(ActionEvent e) {
//				boolean showTextPanel = false;
//				boolean showFormPanel = false;
//				boolean showTablePanel = false;
//				int tabId = 0;
//				
//				TabButtonEvent event = new TabButtonEvent(e, showTextPanel, showFormPanel, showTablePanel, tabId);
//				
//				if (tabButtonListener != null) {
//					tabButtonListener.tabButtonEventOccurred(event);
//				}
//				
//			}
//		});
		
		formPanelTab.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				boolean showTextPanel = false;
				boolean showFormPanel = false;
				boolean showTablePanel = false;
				int tabId = 1;
				
				TabButtonEvent event = new TabButtonEvent(e, showTextPanel, showFormPanel, showTablePanel, tabId);
				
				if (tabButtonListener != null) {
					tabButtonListener.tabButtonEventOccurred(event);
				}
			}
		});
		
		tablePanelTab.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				boolean showTextPanel = false;
				boolean showFormPanel = false;
				boolean showTablePanel = false;
				int tabId = 2;
				
				TabButtonEvent event = new TabButtonEvent(e, showTextPanel, showFormPanel, showTablePanel, tabId);
				
				if (tabButtonListener != null) {
					tabButtonListener.tabButtonEventOccurred(event);
				}
			}
		});
		
		
		styling();
	}
	
	
	public void styling() {
		backgroundColor = new Color(238,238,238);
		
//		textPanelTab.setBackground(backgroundColor);
//		textPanelTab.setForeground(Color.black);
		
		formPanelTab.setBackground(backgroundColor);
		
		tablePanelTab.setBackground(backgroundColor);

	}
	
	
	public void setToolBarListener(TabButtonListener listener) {
		this.tabButtonListener = listener;
	}
	
	public void setFormTabButtonVisible(boolean visible) {
		formPanelTab.setVisible(visible);
	}
//	public void setTextTabButtonVisible(boolean visible) {
//		textPanelTab.setVisible(visible);
//	}
	public void setTableTabButtonVisible(boolean visible) {
	tablePanelTab.setVisible(visible);
	}
	
}















