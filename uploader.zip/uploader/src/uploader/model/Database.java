package uploader.model;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;

public class Database {

	private List<Student> students;
	
	
	public Database() {
		students = new LinkedList<Student>();
		
	}
	
	public void addStudent(Student student) {
		students.add(student);
	}
	
	public void removeStudent(int index) {
		students.remove(index);
	}
	
	public List<Student> getStudents() {
		return Collections.unmodifiableList(students);
	}
	
	public void SaveToFile(File file) throws IOException {
		FileOutputStream fos = new FileOutputStream(file);
		ObjectOutputStream oos = new ObjectOutputStream(fos);
		
		Student[] studentss = students.toArray(new Student[students.size()]);
		
		oos.writeObject(studentss);
		
		oos.close();
	}
	
	public void loadFromFile(File file) throws IOException {
		FileInputStream fis = new FileInputStream(file);
		ObjectInputStream ois =  new ObjectInputStream(fis);
		
		try {
			Student[] studentss = (Student[]) ois.readObject();
			
			students.clear();
			
			students.addAll(Arrays.asList(studentss));
			
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		ois.close();
	}
}
