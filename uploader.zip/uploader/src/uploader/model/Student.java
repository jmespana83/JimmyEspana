package uploader.model;

import java.io.Serializable;

public class Student implements Serializable {
	// version id
	private static final long serialVersionUID = 1L;

	private static int count = 0;
	
	private int id;

	private String name;
	private String studentId;
	private String age;
	
	private GradeCategory grade;
	private Gender gender;
	
	
	
	public Student(String name, String studentId, String age, GradeCategory gradeCat, Gender gender) {
		
		this.name = name;
		this.studentId = studentId;
		this.age = age;
		this.grade = gradeCat;
		this.gender = gender;
		
		this.id = count;
		count++;
	}
	
	public int getId() {
		return id;
	}
	
	public void setId(int id) {
		this.id = id;
	}



	public String getName() {
		return name;
	}



	public void setName(String name) {
		this.name = name;
	}



	public String getStudentId() {
		return studentId;
	}



	public void setStudentId(String studentId) {
		this.studentId = studentId;
	}



	public String getAge() {
		return age;
	}



	public void setAge(String age) {
		this.age = age;
	}



	public GradeCategory getGrade() {
		return grade;
	}



	public void setGrade(GradeCategory grade) {
		this.grade = grade;
	}



	public Gender getGender() {
		return gender;
	}



	public void setGender(Gender gender) {
		this.gender = gender;
	}
	
	
	
	
	
	
	
	
}
