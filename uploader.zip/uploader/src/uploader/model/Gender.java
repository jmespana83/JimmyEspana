package uploader.model;

public enum Gender {
	
	male,
	female

}
