package uploader.model;

public enum GradeCategory {

	freshman,
	sophomore,
	junior,
	senior

}
