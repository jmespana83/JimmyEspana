package uploader.controller;

import java.io.File;
import java.io.IOException;
import java.util.List;

import uploader.gui.StudentFormEvent;
import uploader.model.Database;
import uploader.model.Gender;
import uploader.model.GradeCategory;
import uploader.model.Student;

public class Controller {
	
	Database db = new Database();
	
	public List<Student> getStudents() {
		return db.getStudents();                    
	}
	
	public void removeStudent(int index) {
		db.removeStudent(index);
	}

	
	public void addStudent(StudentFormEvent e) {
		
		String name = e.getName();
		String studentId = e.getStudentId();
		String age = e.getAge();
		String gradeId = e.getGrade();
		String gender = e.getGender();
		
		GradeCategory gradeCategory = GradeCategory.freshman;
		
		// sets student grade category
		if (gradeId == "freshman") gradeCategory = GradeCategory.freshman;
		else if (gradeId == "sophomore") gradeCategory = GradeCategory.sophomore;
		else if (gradeId == "junior") gradeCategory = GradeCategory.junior;
		else if (gradeId == "senior") gradeCategory = GradeCategory.senior;
		
		Gender genderCategory = Gender.male;
		
		if (gender == "male") {
			genderCategory = Gender.male;
		}
		else {
			genderCategory = Gender.female;
		}
		
		Student student = new Student( name, studentId, age, gradeCategory, genderCategory);
		
		db.addStudent(student);
	}
	
	public void saveToFile(File file) throws IOException {
		db.SaveToFile(file);
	}
	
	public void loadFromFile(File file) throws IOException {
		db.loadFromFile(file);
	}
}
















