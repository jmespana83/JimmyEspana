This is a very simple Python program that takes a list of names of people and puts them into random groups of 4; take a look at the python program file and modify & reuse it as you wish.

File "class_period_1.txt" is essentially useless; you can use it to simply store the names of the people you want to randomize into groups. You'll have to copy them over into the file "random_groups-of-4_classPeriod1.py" into the appropriate spots using the correct syntax of course.

File "class_period_1_groups.txt" is the final product from running the "random_groups-of-4_classPeriod1.py" program.

You will need to have python installed, and/or you may actually use:
https://repl.it/languages/python3

It's very convenient to use (and doesn't require you to install anything, all the python execution is done within your browser window).


Thanks for checking out my code, enjoy!