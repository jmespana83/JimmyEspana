import random
import math

#### List of students in said class
####
class_period_1 = ["Frank Darabont",
"Robert Kirkman",
"Tony Moore",
"Angela Kang",
"Geraldine Inoa",
"Scott M. Gimple",
"Matthew Negrete",
"Channing Powell",
"Vivian Tse",
"Eddie Guzelian",
"Corey Reed",
"David Leslie Johnson-McGoldrick",
"Seth Hoffman",
"Glen Mazzara",
"Evan T. Reilly",
"Nichole Beattie",
"Heather Bellson",
"Julia Ruchman",
"Curtis Gwinn",
"Jim Barnes",
"Kevin Deiboldt",
"Eli Jorne",
"Nicole Mirante-Matthews"]


##### Okay let's randomize
#####
random.shuffle(class_period_1)


##### create a file that we can write to
#####
f = open("class_period_1.txt","w+")


##### let's iterate thru the newly randomize list of students
##### and write their names to the file
for i in class_period_1:
   f.write(i + "\n")

#### okay let's close the file, we're done with it
####
f.close() 


#### read the newly created file with student names
#### that were randomized by opening it up
f = open("class_period_1.txt", "r")

######## read line by line said file
linesFromFile = f.readlines()

######## variables that will help us complete the task of grouping the students into groups of 4
########
num_of_names = len(linesFromFile)
count = -1
group_num = 1
num_of_groups = math.ceil(num_of_names / 4)  ####### if this results in a decimal number then simply round it up


#### open & create a new file that will have the grouping of the students in groups of 4
####
f2 = open("class_period_1_groups.txt","w+")

#### iterate thru the names in the randomized file
#### and start breaking them up into groups
#### write this to the 2nd new file we're creating
#### and print this information to the screen
####
for name in linesFromFile:

   ## increment our count variable which helps us track the current number of student that is being processed
   count = count + 1

   ## if we've processed 4 students already, then let's start on the next Group
   if count%4 == 0:

      # write to file and print to the screen
      f2.write("\n\n\n[ Group " + str(group_num) + " .... ]\n\n")
      print("\n\n\n[ Group " + str(group_num) + " .... ]\n\n")

      # increment our group num variable to go onto the next group to be processed
      group_num = group_num + 1

   # print out the current student name and also write it to the 2nd file
   f2.write("\n" + name + "\n")
   print(name)


##### close the 2nd file because we're done with it
f2.close()

